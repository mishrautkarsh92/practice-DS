package com.sapient.productcatalogue.model;

public enum Size {
     SMALL,MEDIUM,LARGE,EXTRA_LARGE
}

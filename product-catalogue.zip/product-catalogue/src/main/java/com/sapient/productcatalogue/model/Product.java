package com.sapient.productcatalogue.model;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long productId;
	private String productName;
	private String color;
	private Size size;
	private String sku;
	private BigDecimal price;
	//@ManyToOne(cascade = CascadeType.ALL)
	private String brand;
	//@ManyToOne(cascade = CascadeType.ALL)
	private String seller;
}

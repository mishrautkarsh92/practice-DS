package com.sapient.productcatalogue.controller;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.productcatalogue.dao.ProductDao;
import com.sapient.productcatalogue.model.Product;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductDao productDao;
	
	@PostMapping
	public void addProduct(@RequestBody Product p){
		p.setSku(UUID.randomUUID().toString());
		productDao.save(p);
	}
	
	@GetMapping(value="/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable("productId")Long productId){
		Product prod = productDao.findById(productId).get();
		return ResponseEntity.ok().body(prod);
	}

	@DeleteMapping(value="/productId")
	public @ResponseBody void removeProduct(@PathVariable("productId")Long productId) {
		Product prod = productDao.findById(productId).get();
		productDao.delete(prod);
	}
	
	@PutMapping(value="/productId")
	public ResponseEntity<Product> updateProduct(@PathVariable("productId")Long productId,@RequestBody Product p) {
		Product prod = productDao.findById(p.getProductId()).get();
		prod.setBrand(p.getBrand());
		prod.setColor(p.getColor());
		prod.setPrice(p.getPrice());
		prod.setProductName(p.getProductName());
		prod.setSeller(p.getSeller());
		prod.setSize(p.getSize());
		prod.setSku(p.getSku());
		return ResponseEntity.ok(prod);
	}
	
	@GetMapping(value="/sku/{sku}")
	public Product getBySku(@PathVariable("sku")String sku){
		return productDao.getBySku(sku);
	}
	
	@GetMapping
	public Iterable<Product> sortByParam(@RequestParam(value="sort",required=false )String sort){
		Iterable<Product> products = productDao.findAll(Sort.by(Sort.Direction.ASC, sort));
		return products;

	}

	@GetMapping(value="/seller/{seller}")
	public HashMap<String,Integer> getTotalProductBySeller(@PathVariable("seller")String seller){
		List<Product> prodList  = productDao.getBySeller(seller);
		HashMap<String,Integer> map = new HashMap<String,Integer>();
		map.put(seller, prodList.size());
		return map;
	}
	
	
}
